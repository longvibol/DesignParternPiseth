package com.pisethjava.springevent.listener;

import com.pisethjava.springevent.event.OrderCreatedEvent;
import org.springframework.context.event.EventListener;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

@Component
public class EmailEventListener {

    @Order(1)
    @EventListener
    public void sendConfirmationEmail(OrderCreatedEvent event) {
        System.out.printf(
                "[EMAIL] Confirmation sent to %s for order %s%n",
                event.customerEmail(),
                event.orderId()
        );
    }
}
