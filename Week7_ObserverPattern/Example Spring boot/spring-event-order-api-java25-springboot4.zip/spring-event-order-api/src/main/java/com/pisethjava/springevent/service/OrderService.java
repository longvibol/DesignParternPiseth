package com.pisethjava.springevent.service;

import com.pisethjava.springevent.domain.Order;
import com.pisethjava.springevent.dto.CreateOrderRequest;
import com.pisethjava.springevent.dto.OrderResponse;
import com.pisethjava.springevent.event.OrderCreatedEvent;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.UUID;

@Service
public class OrderService {

    private final ApplicationEventPublisher eventPublisher;

    public OrderService(ApplicationEventPublisher eventPublisher) {
        this.eventPublisher = eventPublisher;
    }

    public OrderResponse createOrder(CreateOrderRequest request) {
        Order order = new Order(
                UUID.randomUUID().toString(),
                request.customerEmail(),
                request.productName(),
                request.quantity(),
                LocalDateTime.now()
        );

        // A real application would save the order to a database here.
        System.out.printf("[ORDER] Saved order %s%n", order.orderId());

        OrderCreatedEvent event = new OrderCreatedEvent(
                order.orderId(),
                order.customerEmail(),
                order.productName(),
                order.quantity(),
                order.createdAt()
        );

        eventPublisher.publishEvent(event);

        return new OrderResponse(
                order.orderId(),
                order.customerEmail(),
                order.productName(),
                order.quantity(),
                order.createdAt(),
                "Order created successfully"
        );
    }
}
