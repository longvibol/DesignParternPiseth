package com.pisethjava.springevent.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;

public record CreateOrderRequest(
        @NotBlank(message = "Customer email is required")
        @Email(message = "Customer email must be valid")
        String customerEmail,

        @NotBlank(message = "Product name is required")
        String productName,

        @Min(value = 1, message = "Quantity must be at least 1")
        int quantity
) {
}
