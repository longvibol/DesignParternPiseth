package com.pisethjava.springevent;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringEventOrderApiApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringEventOrderApiApplication.class, args);
    }
}
