package com.pisethjava.springevent.dto;

import java.time.LocalDateTime;

public record OrderResponse(
        String orderId,
        String customerEmail,
        String productName,
        int quantity,
        LocalDateTime createdAt,
        String message
) {
}
