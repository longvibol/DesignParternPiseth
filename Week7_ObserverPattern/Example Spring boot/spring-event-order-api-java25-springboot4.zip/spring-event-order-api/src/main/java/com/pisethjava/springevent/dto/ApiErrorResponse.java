package com.pisethjava.springevent.dto;

import java.time.LocalDateTime;
import java.util.Map;

public record ApiErrorResponse(
        int status,
        String error,
        Map<String, String> validationErrors,
        LocalDateTime timestamp
) {
}
