package com.pisethjava.springevent.domain;

import java.time.LocalDateTime;

public record Order(
        String orderId,
        String customerEmail,
        String productName,
        int quantity,
        LocalDateTime createdAt
) {
}
