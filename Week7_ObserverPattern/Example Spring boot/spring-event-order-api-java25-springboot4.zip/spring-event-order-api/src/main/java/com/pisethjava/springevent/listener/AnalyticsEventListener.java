package com.pisethjava.springevent.listener;

import com.pisethjava.springevent.event.OrderCreatedEvent;
import org.springframework.context.event.EventListener;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

@Component
public class AnalyticsEventListener {

    @Order(3)
    @EventListener
    public void recordAnalytics(OrderCreatedEvent event) {
        System.out.printf(
                "[ANALYTICS] Recorded order %s created at %s%n",
                event.orderId(),
                event.createdAt()
        );
    }
}
