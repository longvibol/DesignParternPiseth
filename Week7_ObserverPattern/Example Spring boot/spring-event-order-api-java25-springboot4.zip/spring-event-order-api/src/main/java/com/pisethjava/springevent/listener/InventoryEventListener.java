package com.pisethjava.springevent.listener;

import com.pisethjava.springevent.event.OrderCreatedEvent;
import org.springframework.context.event.EventListener;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

@Component
public class InventoryEventListener {

    @Order(2)
    @EventListener
    public void updateInventory(OrderCreatedEvent event) {
        System.out.printf(
                "[INVENTORY] Reduced %d item(s) from product '%s'%n",
                event.quantity(),
                event.productName()
        );
    }
}
