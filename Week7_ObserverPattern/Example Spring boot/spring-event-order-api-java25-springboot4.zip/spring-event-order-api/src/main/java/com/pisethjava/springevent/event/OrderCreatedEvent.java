package com.pisethjava.springevent.event;

import java.time.LocalDateTime;

public record OrderCreatedEvent(
        String orderId,
        String customerEmail,
        String productName,
        int quantity,
        LocalDateTime createdAt
) {
}
