# Spring Event Order API

A runnable Observer Pattern sample using:

- Java 25
- Spring Boot 4.1.0
- Spring MVC REST API
- Spring `ApplicationEventPublisher`
- `@EventListener`
- Jakarta Bean Validation
- MockMvc integration tests
- Postman collection

## Requirements

- JDK 25
- Maven 3.6.3 or newer
- Postman (optional)

Check:

```bash
java -version
mvn -version
```

Make sure Maven reports Java 25.

## Run

From the project directory:

```bash
mvn clean spring-boot:run
```

The application starts at:

```text
http://localhost:8080
```

Health check:

```text
GET http://localhost:8080/api/orders/health
```

## Create an order

```http
POST http://localhost:8080/api/orders
Content-Type: application/json
```

Body:

```json
{
  "customerEmail": "david@example.com",
  "productName": "Dell Laptop",
  "quantity": 2
}
```

Expected status: `201 Created`

Example response:

```json
{
  "orderId": "generated-uuid",
  "customerEmail": "david@example.com",
  "productName": "Dell Laptop",
  "quantity": 2,
  "createdAt": "2026-07-24T14:30:00",
  "message": "Order created successfully"
}
```

Console:

```text
[ORDER] Saved order ...
[EMAIL] Confirmation sent ...
[INVENTORY] Reduced 2 item(s) ...
[ANALYTICS] Recorded order ...
```

## Run tests

```bash
mvn clean test
```

## Build and run JAR

```bash
mvn clean package
java -jar target/spring-event-order-api-0.0.1-SNAPSHOT.jar
```

## Postman

Import these two files from the `postman` folder:

1. `Spring-Event-Order-API.postman_collection.json`
2. `Local.postman_environment.json`

Choose the `Local` environment and run the requests.

## Observer Pattern mapping

| Observer Pattern | This project |
|---|---|
| Publisher | `ApplicationEventPublisher` |
| Event | `OrderCreatedEvent` |
| Observer | Classes with `@EventListener` |
| Publish | `eventPublisher.publishEvent(event)` |
| Notification | Spring invokes matching listener methods |

Spring application events are local to this application. For communication between separate microservices, use Kafka, RabbitMQ, or another message broker.
